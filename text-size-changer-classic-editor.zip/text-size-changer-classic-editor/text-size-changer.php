<?php
/**
 * Plugin Name: Text Size Changer for Classic Editor
 * Description: افزونه‌ای برای تغییر سایز متن انتخابی در ویرایشگر کلاسیک وردپرس
 * Version: 1.0
 * Author: skillhunt.ir
 * License: GPL2
 */

// جلوگیری از دسترسی مستقیم به فایل
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// افزودن اسکریپت و استایل‌ها به ویرایشگر کلاسیک وردپرس
function tsc_enqueue_scripts() {
    // فقط برای ویرایشگر کلاسیک
    if ( is_admin() && get_current_screen()->id === 'post' ) {
        wp_enqueue_script( 'tsc-scripts', plugin_dir_url( __FILE__ ) . 'script.js', array('jquery'), null, true );
        wp_enqueue_style( 'tsc-styles', plugin_dir_url( __FILE__ ) . 'style.css' );
    }
}

add_action( 'admin_enqueue_scripts', 'tsc_enqueue_scripts' );

// اضافه کردن دکمه به نوار ابزار ویرایشگر کلاسیک
function tsc_add_text_size_button( $buttons ) {
    array_push( $buttons, 'separator', 'text_size_button' );
    return $buttons;
}

add_filter( 'mce_buttons', 'tsc_add_text_size_button' );

// اضافه کردن تنظیمات برای دکمه سفارشی
function tsc_add_text_size_plugin( $plugin_array ) {
    $plugin_array['text_size_button'] = plugin_dir_url( __FILE__ ) . 'script.js';
    return $plugin_array;
}

add_filter( 'mce_external_plugins', 'tsc_add_text_size_plugin' );

// تعریف دکمه سفارشی برای ویرایشگر
function tsc_mce_button_js() {
    ?>
    <script type="text/javascript">
        (function() {
            tinymce.create('tinymce.plugins.text_size_button', {
                init : function(ed, url) {
                    ed.addButton('text_size_button', {
                        title : 'Change Text Size',
                        image : '<?php echo plugin_dir_url( __FILE__ ) . 'icon.png'; ?>',
                        onclick : function() {
                            var size = prompt("Enter the font size (px):", "16");
                            if (size != null && !isNaN(size) && size >= 10 && size <= 100) {
                                ed.selection.setContent('<span style="font-size:' + size + 'px">' + ed.selection.getContent() + '</span>');
                            } else {
                                alert("Please enter a valid number between 10 and 100.");
                            }
                        }
                    });
                }
            });
            tinymce.PluginManager.add('text_size_button', tinymce.plugins.text_size_button);
        })();
    </script>
    <?php
}

add_action( 'admin_footer', 'tsc_mce_button_js' );
