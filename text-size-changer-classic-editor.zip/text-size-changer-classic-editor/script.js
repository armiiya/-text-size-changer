(function() {
    tinymce.create('tinymce.plugins.text_size_button', {
        init : function(ed, url) {
            ed.addButton('text_size_button', {
                title : 'Change Text Size',
                image : url + '/icon.png',
                onclick : function() {
                    var size = prompt("Enter the font size (px):", "16");
                    if (size != null && !isNaN(size) && size >= 10 && size <= 100) {
                        ed.selection.setContent('<span style="font-size:' + size + 'px">' + ed.selection.getContent() + '</span>');
                    } else {
                        alert("Please enter a valid number between 10 and 100.");
                    }
                }
            });
        }
    });
    tinymce.PluginManager.add('text_size_button', tinymce.plugins.text_size_button);
})();
